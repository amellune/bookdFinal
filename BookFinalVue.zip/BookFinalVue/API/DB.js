module.exports = {
    DB: 'mongodb+srv://Jessie:Mongodb@bookd.hy23l.mongodb.net/test'
}
