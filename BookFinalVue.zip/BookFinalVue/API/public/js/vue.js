var example1 = new Vue({
    el: '#example-1',
    data: {
      counter: 0
    }
  })