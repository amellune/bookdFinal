// post.model.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
// let Post = new Schema({
    
//   title: {
//     type: String
//   },
//   body: {
//     type: String
//   }
// },{
//     collection: 'posts'
// });


let Post = new Schema({
  img:
    {
      type: String,   
    },    
  title: {
    type: String, 
   
  },
  author: {
    type: String
  },
  description: {
    type: String
  },
  genre:{
    type:String
  },
  keywords:{
    type:Array
  }

},{
    collection: 'posts'
});





module.exports = mongoose.model('Post', Post);
